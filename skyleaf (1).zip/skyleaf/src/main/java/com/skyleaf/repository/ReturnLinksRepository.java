package com.skyleaf.repository;

import org.springframework.data.repository.CrudRepository;

import com.skyleaf.beans.ReturnLinks;

public interface ReturnLinksRepository extends CrudRepository<ReturnLinks,String> {

	
}

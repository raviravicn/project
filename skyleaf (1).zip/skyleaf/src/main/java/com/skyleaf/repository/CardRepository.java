package com.skyleaf.repository;

import org.springframework.data.repository.CrudRepository;

import com.skyleaf.beans.Card;

public interface CardRepository extends CrudRepository<Card, String>{

}

package com.skyleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkyleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
